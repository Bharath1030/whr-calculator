ol.proj.proj4.register(proj4);
//ol.proj.get("EPSG:3035").setExtent([3118613.068844, 1852732.006155, 5117149.823912, 4270316.790511]);
var wms_layers = [];


        var lyr_ESRIGraylight_0 = new ol.layer.Tile({
            'title': 'ESRI Gray (light)',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://services.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}'
            })
        });
var format_Ringsmfromcenter_1 = new ol.format.GeoJSON();
var features_Ringsmfromcenter_1 = format_Ringsmfromcenter_1.readFeatures(json_Ringsmfromcenter_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3035'});
var jsonSource_Ringsmfromcenter_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Ringsmfromcenter_1.addFeatures(features_Ringsmfromcenter_1);
var lyr_Ringsmfromcenter_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Ringsmfromcenter_1, 
                style: style_Ringsmfromcenter_1,
                popuplayertitle: 'Rings (m from center)',
                interactive: false,
    title: 'Rings (m from center)<br />\
    <img src="styles/legend/Ringsmfromcenter_1_0.png" /> 500.000000<br />\
    <img src="styles/legend/Ringsmfromcenter_1_1.png" /> 1000.000000<br />\
    <img src="styles/legend/Ringsmfromcenter_1_2.png" /> 1500.000000<br />\
    <img src="styles/legend/Ringsmfromcenter_1_3.png" /> 2000.000000<br />\
    <img src="styles/legend/Ringsmfromcenter_1_4.png" /> 2500.000000<br />\
    <img src="styles/legend/Ringsmfromcenter_1_5.png" /> 3000.000000<br />\
    <img src="styles/legend/Ringsmfromcenter_1_6.png" /> <br />' });
var format_FBManufacturingSitesWithin3km_2 = new ol.format.GeoJSON();
var features_FBManufacturingSitesWithin3km_2 = format_FBManufacturingSitesWithin3km_2.readFeatures(json_FBManufacturingSitesWithin3km_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3035'});
var jsonSource_FBManufacturingSitesWithin3km_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_FBManufacturingSitesWithin3km_2.addFeatures(features_FBManufacturingSitesWithin3km_2);
var lyr_FBManufacturingSitesWithin3km_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_FBManufacturingSitesWithin3km_2, 
                style: style_FBManufacturingSitesWithin3km_2,
                popuplayertitle: 'F&B Manufacturing Sites Within 3 km',
                interactive: true,
                title: '<img src="styles/legend/FBManufacturingSitesWithin3km_2.png" /> F&B Manufacturing Sites Within 3 km'
            });
var format_MicrosoftDataCenters_3 = new ol.format.GeoJSON();
var features_MicrosoftDataCenters_3 = format_MicrosoftDataCenters_3.readFeatures(json_MicrosoftDataCenters_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3035'});
var jsonSource_MicrosoftDataCenters_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_MicrosoftDataCenters_3.addFeatures(features_MicrosoftDataCenters_3);
var lyr_MicrosoftDataCenters_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_MicrosoftDataCenters_3, 
                style: style_MicrosoftDataCenters_3,
                popuplayertitle: 'Microsoft Data Centers',
                interactive: true,
                title: '<img src="styles/legend/MicrosoftDataCenters_3.png" /> Microsoft Data Centers'
            });

lyr_ESRIGraylight_0.setVisible(true);lyr_Ringsmfromcenter_1.setVisible(true);lyr_FBManufacturingSitesWithin3km_2.setVisible(true);lyr_MicrosoftDataCenters_3.setVisible(true);
var layersList = [lyr_ESRIGraylight_0,lyr_Ringsmfromcenter_1,lyr_FBManufacturingSitesWithin3km_2,lyr_MicrosoftDataCenters_3];
lyr_Ringsmfromcenter_1.set('fieldAliases', {'fid': 'fid', 'Data_Cente': 'Data_Cente', 'Operator': 'Operator', 'Metro_Area': 'Metro_Area', 'Address': 'Address', 'lat': 'lat', 'long': 'long', 'latlon': 'latlon', 'Dnaics_dun': 'Dnaics_dun', 'Dnaics_m': 'Dnaics_m', 'Dnace_duns': 'Dnace_duns', 'Dnace_m': 'Dnace_m', 'Eia_id': 'Eia_id', 'Eia_m': 'Eia_m', 'Enace_id': 'Enace_id', 'Enace_m': 'Enace_m', 'neardc_m': 'neardc_m', 'near_id': 'near_id', 'near_duns': 'near_duns', 'cnt_0500': 'cnt_0500', 'cnt_1000': 'cnt_1000', 'cnt_1500': 'cnt_1500', 'cnt_2000': 'cnt_2000', 'cnt_2500': 'cnt_2500', 'cnt_3000': 'cnt_3000', 'ringId': 'ringId', 'distance': 'distance', });
lyr_FBManufacturingSitesWithin3km_2.set('fieldAliases', {'fid': 'fid', 'D-U-N-S®': 'D-U-N-S®', 'FacilityID': 'FacilityID', 'Employees': 'Employees', 'Dnaics_Emp': 'Dnaics_Emp', 'Dnace_Empl': 'Dnace_Empl', 'eia_Operat': 'eia_Operat', 'eia_TotalE': 'eia_TotalE', 'enace_Oper': 'enace_Oper', 'enace_Tota': 'enace_Tota', 'HubName': 'HubName', 'Distance to data center (m)': 'Distance to data center (m)', 'Company Na': 'Company Na', 'Global Ult': 'Global Ult', 'Address Li': 'Address Li', 'Address _1': 'Address _1', 'Latitude1': 'Latitude1', 'longit1': 'longit1', 'NACE Rev 2': 'NACE Rev 2', 'NACE Rev_1': 'NACE Rev_1', 'ParentComp': 'ParentComp', 'FacilityNa': 'FacilityNa', 'StreetName': 'StreetName', 'BuildingNu': 'BuildingNu', 'City': 'City', 'Lat': 'Lat', 'Long': 'Long', 'NACEMainEc': 'NACEMainEc', 'NACEMain_1': 'NACEMain_1', 'ParentCompanyName': 'ParentCompanyName', 'FacilityName': 'FacilityName', 'BuildingNumber': 'BuildingNumber', 'NACEMainEconomicActivityCode': 'NACEMainEconomicActivityCode', 'NACEMainEconomicActivityName': 'NACEMainEconomicActivityName', 'Facility Name': 'Facility Name', 'Address': 'Address', 'Longitude': 'Longitude', 'Latitude': 'Latitude', 'Parent Company': 'Parent Company', 'NACE Rev 2 Code': 'NACE Rev 2 Code', 'NACE Activity Name': 'NACE Activity Name', 'Source': 'Source', });
lyr_MicrosoftDataCenters_3.set('fieldAliases', {'fid': 'fid', 'Data Center': 'Data Center', 'Operator': 'Operator', 'Metro Area': 'Metro Area', 'Address': 'Address', 'Latitude': 'Latitude', 'Longitude': 'Longitude', 'latlon': 'latlon', 'Dnaics_dun': 'Dnaics_dun', 'Dnaics_m': 'Dnaics_m', 'Dnace_duns': 'Dnace_duns', 'Dnace_m': 'Dnace_m', 'Eia_id': 'Eia_id', 'Eia_m': 'Eia_m', 'Enace_id': 'Enace_id', 'Enace_m': 'Enace_m', 'near_id': 'near_id', 'near_duns': 'near_duns', 'cnt_0500': 'cnt_0500', 'cnt_1000': 'cnt_1000', 'cnt_1500': 'cnt_1500', 'cnt_2000': 'cnt_2000', 'cnt_2500': 'cnt_2500', 'cnt_3000': 'cnt_3000', });
lyr_Ringsmfromcenter_1.set('fieldImages', {'fid': 'TextEdit', 'Data_Cente': 'TextEdit', 'Operator': 'TextEdit', 'Metro_Area': 'TextEdit', 'Address': 'TextEdit', 'lat': 'TextEdit', 'long': 'TextEdit', 'latlon': 'TextEdit', 'Dnaics_dun': 'TextEdit', 'Dnaics_m': 'TextEdit', 'Dnace_duns': 'TextEdit', 'Dnace_m': 'TextEdit', 'Eia_id': 'TextEdit', 'Eia_m': 'TextEdit', 'Enace_id': 'TextEdit', 'Enace_m': 'TextEdit', 'neardc_m': 'TextEdit', 'near_id': 'TextEdit', 'near_duns': 'TextEdit', 'cnt_0500': 'Range', 'cnt_1000': 'Range', 'cnt_1500': 'Range', 'cnt_2000': 'Range', 'cnt_2500': 'Range', 'cnt_3000': 'Range', 'ringId': 'TextEdit', 'distance': 'TextEdit', });
lyr_FBManufacturingSitesWithin3km_2.set('fieldImages', {'fid': 'TextEdit', 'D-U-N-S®': 'TextEdit', 'FacilityID': 'TextEdit', 'Employees': 'TextEdit', 'Dnaics_Emp': 'TextEdit', 'Dnace_Empl': 'TextEdit', 'eia_Operat': 'TextEdit', 'eia_TotalE': 'TextEdit', 'enace_Oper': 'TextEdit', 'enace_Tota': 'TextEdit', 'HubName': 'TextEdit', 'Distance to data center (m)': 'TextEdit', 'Company Na': 'TextEdit', 'Global Ult': 'TextEdit', 'Address Li': 'TextEdit', 'Address _1': 'TextEdit', 'Latitude1': 'TextEdit', 'longit1': 'TextEdit', 'NACE Rev 2': 'TextEdit', 'NACE Rev_1': 'TextEdit', 'ParentComp': 'TextEdit', 'FacilityNa': 'TextEdit', 'StreetName': 'TextEdit', 'BuildingNu': 'TextEdit', 'City': 'TextEdit', 'Lat': 'TextEdit', 'Long': 'TextEdit', 'NACEMainEc': 'TextEdit', 'NACEMain_1': 'TextEdit', 'ParentCompanyName': 'TextEdit', 'FacilityName': 'TextEdit', 'BuildingNumber': 'TextEdit', 'NACEMainEconomicActivityCode': 'TextEdit', 'NACEMainEconomicActivityName': 'TextEdit', 'Facility Name': 'TextEdit', 'Address': 'TextEdit', 'Longitude': 'TextEdit', 'Latitude': 'TextEdit', 'Parent Company': 'TextEdit', 'NACE Rev 2 Code': 'TextEdit', 'NACE Activity Name': 'TextEdit', 'Source': 'TextEdit', });
lyr_MicrosoftDataCenters_3.set('fieldImages', {'fid': 'TextEdit', 'Data Center': 'TextEdit', 'Operator': 'TextEdit', 'Metro Area': 'TextEdit', 'Address': 'TextEdit', 'Latitude': 'TextEdit', 'Longitude': 'TextEdit', 'latlon': 'TextEdit', 'Dnaics_dun': 'TextEdit', 'Dnaics_m': 'TextEdit', 'Dnace_duns': 'TextEdit', 'Dnace_m': 'TextEdit', 'Eia_id': 'TextEdit', 'Eia_m': 'TextEdit', 'Enace_id': 'TextEdit', 'Enace_m': 'TextEdit', 'near_id': 'TextEdit', 'near_duns': 'TextEdit', 'cnt_0500': 'Range', 'cnt_1000': 'Range', 'cnt_1500': 'Range', 'cnt_2000': 'Range', 'cnt_2500': 'Range', 'cnt_3000': 'Range', });
lyr_Ringsmfromcenter_1.set('fieldLabels', {'fid': 'no label', 'Data_Cente': 'no label', 'Operator': 'no label', 'Metro_Area': 'no label', 'Address': 'no label', 'lat': 'no label', 'long': 'no label', 'latlon': 'no label', 'Dnaics_dun': 'no label', 'Dnaics_m': 'no label', 'Dnace_duns': 'no label', 'Dnace_m': 'no label', 'Eia_id': 'no label', 'Eia_m': 'no label', 'Enace_id': 'no label', 'Enace_m': 'no label', 'neardc_m': 'no label', 'near_id': 'no label', 'near_duns': 'no label', 'cnt_0500': 'no label', 'cnt_1000': 'no label', 'cnt_1500': 'no label', 'cnt_2000': 'no label', 'cnt_2500': 'no label', 'cnt_3000': 'no label', 'ringId': 'no label', 'distance': 'no label', });
lyr_FBManufacturingSitesWithin3km_2.set('fieldLabels', {'fid': 'hidden field', 'D-U-N-S®': 'hidden field', 'FacilityID': 'hidden field', 'Employees': 'inline label - always visible', 'Dnaics_Emp': 'hidden field', 'Dnace_Empl': 'hidden field', 'eia_Operat': 'hidden field', 'eia_TotalE': 'hidden field', 'enace_Oper': 'hidden field', 'enace_Tota': 'hidden field', 'HubName': 'hidden field', 'Distance to data center (m)': 'inline label - always visible', 'Company Na': 'hidden field', 'Global Ult': 'hidden field', 'Address Li': 'hidden field', 'Address _1': 'hidden field', 'Latitude1': 'hidden field', 'longit1': 'hidden field', 'NACE Rev 2': 'hidden field', 'NACE Rev_1': 'hidden field', 'ParentComp': 'hidden field', 'FacilityNa': 'hidden field', 'StreetName': 'hidden field', 'BuildingNu': 'hidden field', 'City': 'hidden field', 'Lat': 'hidden field', 'Long': 'hidden field', 'NACEMainEc': 'hidden field', 'NACEMain_1': 'hidden field', 'ParentCompanyName': 'hidden field', 'FacilityName': 'hidden field', 'BuildingNumber': 'hidden field', 'NACEMainEconomicActivityCode': 'hidden field', 'NACEMainEconomicActivityName': 'hidden field', 'Facility Name': 'inline label - always visible', 'Address': 'inline label - always visible', 'Longitude': 'inline label - always visible', 'Latitude': 'inline label - always visible', 'Parent Company': 'inline label - visible with data', 'NACE Rev 2 Code': 'inline label - visible with data', 'NACE Activity Name': 'inline label - visible with data', 'Source': 'inline label - visible with data', });
lyr_MicrosoftDataCenters_3.set('fieldLabels', {'fid': 'hidden field', 'Data Center': 'inline label - always visible', 'Operator': 'inline label - always visible', 'Metro Area': 'inline label - always visible', 'Address': 'inline label - always visible', 'Latitude': 'inline label - always visible', 'Longitude': 'inline label - always visible', 'latlon': 'hidden field', 'Dnaics_dun': 'hidden field', 'Dnaics_m': 'hidden field', 'Dnace_duns': 'hidden field', 'Dnace_m': 'hidden field', 'Eia_id': 'hidden field', 'Eia_m': 'hidden field', 'Enace_id': 'hidden field', 'Enace_m': 'hidden field', 'Distance to Nearest F&B Site (m)': 'hidden field', 'near_id': 'hidden field', 'near_duns': 'hidden field', 'cnt_0500': 'hidden field', 'cnt_1000': 'hidden field', 'cnt_1500': 'hidden field', 'cnt_2000': 'hidden field', 'cnt_2500': 'hidden field', 'cnt_3000': 'hidden field', });
lyr_MicrosoftDataCenters_3.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});